// Subclase Cuadrado
class Cuadrado extends Formas {
    private double area;
    
    public Cuadrado(double area) {
        this.area = area;
    }

    public void calcularArea() {
        System.out.println("El área del cuadrado es: " + area);
    }

    @Override
    public void dibujar() {
        System.out.println("Dibujando un cuadrado");
    }
}
