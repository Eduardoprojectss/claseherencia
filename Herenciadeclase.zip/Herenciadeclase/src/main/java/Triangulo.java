// Subclase Triangulo
class Triangulo extends Formas {
    private double angulo;

    public Triangulo(double angulo) {
        this.angulo = angulo;
    }

    public void calcularArea() {
        System.out.println("Calculando el área del triángulo con ángulo: " + angulo);
    }

    @Override
    public void dibujar() {
        System.out.println("Dibujando un triángulo");
    }
}
