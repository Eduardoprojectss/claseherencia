// Subclase Circulo
class Circulo extends Formas {
    private double radio;
    public Circulo(double radio) {
        this.radio = radio;
    }

    public void calcularRadio() {
        System.out.println("El radio del círculo es: " + radio);
    }

    @Override
    public void dibujar() {
        System.out.println("Dibujando un círculo");
    }
}
